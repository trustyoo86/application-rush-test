"use strict";
exports.id = 632;
exports.ids = [632];
exports.modules = {

/***/ 2790:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8067);


function MyApp({ Component , pageProps  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
        ...pageProps
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyApp);


/***/ }),

/***/ 7020:
/***/ ((module) => {

module.exports = JSON.parse('{"polyfillFiles":["static/chunks/polyfills-5cd94c89d3acac5f.js"],"devFiles":[],"ampDevFiles":[],"lowPriorityFiles":["static/1otzktUXXYt0SIW7jeCr2/_buildManifest.js","static/1otzktUXXYt0SIW7jeCr2/_ssgManifest.js","static/1otzktUXXYt0SIW7jeCr2/_middlewareManifest.js"],"pages":{"/":["static/chunks/webpack-69bfa6990bb9e155.js","static/chunks/framework-1cc214ea2e034b34.js","static/chunks/main-a2dcfd6d83dba07e.js","static/css/149b18973e5508c7.css","static/chunks/pages/index-079cc8464f1b4dc3.js"],"/_app":["static/chunks/webpack-69bfa6990bb9e155.js","static/chunks/framework-1cc214ea2e034b34.js","static/chunks/main-a2dcfd6d83dba07e.js","static/css/27d177a30947857b.css","static/chunks/pages/_app-2b49df01f84e0cc3.js"],"/_error":["static/chunks/webpack-69bfa6990bb9e155.js","static/chunks/framework-1cc214ea2e034b34.js","static/chunks/main-a2dcfd6d83dba07e.js","static/chunks/pages/_error-2aa161e09da6b150.js"]},"ampFirstPages":[]}');

/***/ }),

/***/ 3978:
/***/ ((module) => {

module.exports = {};

/***/ }),

/***/ 9450:
/***/ ((module) => {

module.exports = {"Dg":[]};

/***/ })

};
;